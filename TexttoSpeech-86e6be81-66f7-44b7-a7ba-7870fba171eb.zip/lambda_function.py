import json
import boto3
import base64

# Initialize Polly client
polly = boto3.client('polly')

def lambda_handler(event, context):
    # Extract text from the incoming event
    text = json.loads(event['body'])['text']
    
    # Set up Polly synthesis parameters
    params = {
        'Text': text,
        'OutputFormat': 'mp3',
        'VoiceId': 'Joanna'  # Choose a voice you prefer
    }
    
    try:
        # Call Polly to synthesize speech
        response = polly.synthesize_speech(**params)
        
        # Get the audio stream and encode it as base64
        audio_stream = response['AudioStream'].read()
        audio_base64 = base64.b64encode(audio_stream).decode('utf-8')
        
        # Return the audio as base64 in the response
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Text to Speech successful',
                'audioStream': audio_base64
            }),
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        }
        
    except Exception as e:
        # Handle any errors and return them in the response
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)}),
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        }
